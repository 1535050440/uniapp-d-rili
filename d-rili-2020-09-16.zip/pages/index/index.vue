<template>
	<view class="content">
		<view class="wrapper">
			d-rili日历 - 可左右滑动
		</view>
		
		<!--  -->
		<d-rili></d-rili>
		<!--  -->
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>

<style>
	.wrapper {
		width: 100%;
		height: 200rpx;
		background-color: pink;
		color: #fff;
		font-size: 40rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	
</style>
